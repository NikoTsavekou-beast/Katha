export default function Home() {
  return (
    <main>
      {/* Hero Section */}
      <section className="hero">
        <div className="hero-content">
          <div className="hero-text">
            <h1>Pure Creatine. Clean Hydration.</h1>
            <p>
              KATHA is the cleanest creatine stick pack you've ever used. 3g creatine monohydrate. 1.1g electrolytes. 0g sugar. That's it.
            </p>
            <p style={{ fontSize: '1rem', color: '#888', marginBottom: '2rem' }}>
              Pre-order now. Shipping starts July 2026.
            </p>
            <a href="/shop" className="btn btn-accent">Pre-Order Now</a>
          </div>
          <div className="hero-image">
            <div style={{
              width: '300px',
              height: '320px',
              background: '#f5f5f5',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: '0.9rem',
              color: '#999',
              textAlign: 'center',
              padding: '1rem'
            }}>
              [Hero product image - 3 sticks]
            </div>
          </div>
        </div>
      </section>

      {/* Quick Facts */}
      <section style={{
        background: '#f9f9f9',
        padding: '4rem 2rem'
      }}>
        <div className="container">
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
            gap: '2rem',
            maxWidth: '1200px',
            margin: '0 auto'
          }}>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: '2.2rem', fontWeight: '900', marginBottom: '0.5rem' }}>3g</div>
              <div style={{ fontSize: '0.95rem', color: '#555' }}>Creatine Monohydrate</div>
            </div>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: '2.2rem', fontWeight: '900', marginBottom: '0.5rem' }}>1.1g</div>
              <div style={{ fontSize: '0.95rem', color: '#555' }}>Electrolytes</div>
            </div>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: '2.2rem', fontWeight: '900', marginBottom: '0.5rem' }}>0g</div>
              <div style={{ fontSize: '0.95rem', color: '#555' }}>Sugar</div>
            </div>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: '2.2rem', fontWeight: '900', marginBottom: '0.5rem', color: '#EF5A22' }}>3</div>
              <div style={{ fontSize: '0.95rem', color: '#555' }}>Flavors</div>
            </div>
          </div>
        </div>
      </section>

      {/* Product Preview */}
      <section className="section">
        <h2 className="section-title">Our Flavors</h2>
        <p className="section-subtitle">Same formula. Different vibe.</p>
        
        <div className="product-grid">
          {/* Watermelon */}
          <div className="product-card">
            <div className="product-image">
              <div style={{ fontSize: '3rem' }}>🍉</div>
            </div>
            <div className="product-flavor watermelon">Watermelon</div>
            <div className="product-name">KATHA Watermelon</div>
            <div className="product-description">
              Fresh, crisp watermelon. The OG flavor that started it all.
            </div>
            <div className="product-specs">
              <div className="spec">
                <strong>Creatine:</strong>
                <span>3g</span>
              </div>
              <div className="spec">
                <strong>Electrolytes:</strong>
                <span>1.1g</span>
              </div>
              <div className="spec">
                <strong>Sugar:</strong>
                <span>0g</span>
              </div>
            </div>
            <a href="/shop" className="btn">Shop</a>
          </div>

          {/* Lemon Lime */}
          <div className="product-card">
            <div className="product-image">
              <div style={{ fontSize: '3rem' }}>🍋</div>
            </div>
            <div className="product-flavor lemon-lime">Lemon Lime</div>
            <div className="product-name">KATHA Lemon Lime</div>
            <div className="product-description">
              Citrusy punch. Bright, clean, and instantly refreshing.
            </div>
            <div className="product-specs">
              <div className="spec">
                <strong>Creatine:</strong>
                <span>3g</span>
              </div>
              <div className="spec">
                <strong>Electrolytes:</strong>
                <span>1.1g</span>
              </div>
              <div className="spec">
                <strong>Sugar:</strong>
                <span>0g</span>
              </div>
            </div>
            <a href="/shop" className="btn">Shop</a>
          </div>

          {/* Peach Mango */}
          <div className="product-card">
            <div className="product-image">
              <div style={{ fontSize: '3rem' }}>🥭</div>
            </div>
            <div className="product-flavor peach-mango">Peach Mango</div>
            <div className="product-name">KATHA Peach Mango</div>
            <div className="product-description">
              Tropical blend. Smooth, sweet, and completely sugar-free.
            </div>
            <div className="product-specs">
              <div className="spec">
                <strong>Creatine:</strong>
                <span>3g</span>
              </div>
              <div className="spec">
                <strong>Electrolytes:</strong>
                <span>1.1g</span>
              </div>
              <div className="spec">
                <strong>Sugar:</strong>
                <span>0g</span>
              </div>
            </div>
            <a href="/shop" className="btn">Shop</a>
          </div>
        </div>

        <div style={{ textAlign: 'center', marginTop: '3rem' }}>
          <a href="/shop" className="btn btn-accent">View All Products</a>
        </div>
      </section>

      {/* Why KATHA */}
      <section style={{
        background: '#f9f9f9',
        padding: '5rem 2rem'
      }}>
        <div className="container">
          <h2 className="section-title">Why KATHA?</h2>
          <p className="section-subtitle">Clean. Simple. Effective.</p>
          
          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(260px, 1fr))',
            gap: '2rem',
            maxWidth: '1200px',
            margin: '0 auto'
          }}>
            <div style={{ padding: '2rem', background: '#fff', border: '1px solid #e0e0e0' }}>
              <h3 style={{ marginBottom: '1rem', fontSize: '1.2rem', fontWeight: '700' }}>Pure Creatine</h3>
              <p style={{ color: '#666', lineHeight: '1.7' }}>
                3g of creatine monohydrate. Scientifically proven to boost strength and muscle. No fluff.
              </p>
            </div>
            <div style={{ padding: '2rem', background: '#fff', border: '1px solid #e0e0e0' }}>
              <h3 style={{ marginBottom: '1rem', fontSize: '1.2rem', fontWeight: '700' }}>Complete Hydration</h3>
              <p style={{ color: '#666', lineHeight: '1.7' }}>
                1.1g electrolyte blend (potassium, magnesium, calcium). Designed to maximize hydration and performance.
              </p>
            </div>
            <div style={{ padding: '2rem', background: '#fff', border: '1px solid #e0e0e0' }}>
              <h3 style={{ marginBottom: '1rem', fontSize: '1.2rem', fontWeight: '700' }}>Zero Sugar</h3>
              <p style={{ color: '#666', lineHeight: '1.7' }}>
                Sweetened with monk fruit. No artificial junk. Nothing that doesn't belong.
              </p>
            </div>
            <div style={{ padding: '2rem', background: '#fff', border: '1px solid #e0e0e0' }}>
              <h3 style={{ marginBottom: '1rem', fontSize: '1.2rem', fontWeight: '700' }}>Instant Convenience</h3>
              <p style={{ color: '#666', lineHeight: '1.7' }}>
                Stick pack format. No mixing. No measuring. Just push, shake, and drink.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="section" style={{ textAlign: 'center' }}>
        <h2 className="section-title">Ready to upgrade your routine?</h2>
        <p className="section-subtitle">Join the clean creatine revolution.</p>
        <a href="/shop" className="btn btn-accent" style={{ fontSize: '1.1rem', padding: '1rem 2.5rem' }}>
          Pre-Order Now
        </a>
      </section>
    </main>
  )
}
