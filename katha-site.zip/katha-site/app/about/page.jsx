export default function About() {
  return (
    <main>
      <section className="section">
        <h1 className="section-title">About KATHA</h1>
        <p className="section-subtitle">The story behind pure creatine.</p>

        <div className="about-content">
          <div className="about-text">
            <p>
              KATHA started with a simple frustration: existing creatine products are inefficient. Most are powders that don't dissolve well, mixed with fillers and unnecessary ingredients, and require measuring, mixing, and cleanup.
            </p>
            <p>
              We wanted something better. Something <strong>clean</strong>. Something <strong>convenient</strong>. Something that actually works.
            </p>
            <p>
              ΚΆΘΑ (Katha) comes from the Greek word meaning "pure" or "clean." It's more than a name—it's a commitment. Every stick pack contains exactly what your body needs: creatine monohydrate for strength, electrolytes for hydration, and nothing else.
            </p>
            <p>
              No sugar. No artificial nonsense. No 47 ingredients you can't pronounce. Just the science that works, packaged for the life you actually live.
            </p>
            <p>
              That's the KATHA standard.
            </p>
          </div>

          <div style={{
            background: '#f9f9f9',
            padding: '2rem',
            borderLeft: '4px solid #EF5A22'
          }}>
            <h3 style={{ marginBottom: '1.5rem', fontSize: '1.3rem', fontWeight: '700' }}>
              Why Creatine + Electrolytes?
            </h3>
            <p style={{ marginBottom: '1.5rem', lineHeight: '1.8' }}>
              <strong>Creatine monohydrate</strong> is one of the most researched supplements ever. It increases strength, muscle mass, and performance in high-intensity training. Period.
            </p>
            <p style={{ marginBottom: '1.5rem', lineHeight: '1.8' }}>
              But creatine needs hydration to work optimally. Enter <strong>electrolytes</strong>—potassium, magnesium, and calcium—which support muscle function, prevent cramping, and maximize your body's ability to use creatine.
            </p>
            <p style={{ lineHeight: '1.8' }}>
              Together, they're unstoppable. Separately, you're leaving gains on the table.
            </p>
          </div>
        </div>

        <div className="brand-highlights">
          <div className="highlight">
            <h3>Our Founding</h3>
            <p>
              Built by athletes, for athletes. We started because we were tired of settling for mediocre supplements that don't match the quality of everything else in our lives.
            </p>
          </div>
          <div className="highlight">
            <h3>Our Standard</h3>
            <p>
              Every batch is tested. Every ingredient sourced for purity and efficacy. We don't cut corners, and you shouldn't have to either.
            </p>
          </div>
          <div className="highlight">
            <h3>Our Vision</h3>
            <p>
              To make the cleanest, most convenient supplements available. To prove that premium doesn't have to be complicated.
            </p>
          </div>
          <div className="highlight">
            <h3>Our Promise</h3>
            <p>
              If it's not working for you, we'll make it right. Your results matter to us. Your satisfaction is non-negotiable.
            </p>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section style={{
        background: '#f9f9f9',
        padding: '5rem 2rem'
      }}>
        <div className="section">
          <h2 className="section-title">Our Values</h2>
          <p className="section-subtitle">What we stand for.</p>

          <div style={{
            display: 'grid',
            gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))',
            gap: '2rem',
            maxWidth: '1200px',
            margin: '0 auto'
          }}>
            <div style={{
              padding: '2rem',
              background: '#fff',
              border: '1px solid #e0e0e0',
              borderLeft: '4px solid #EF5A22'
            }}>
              <h3 style={{ marginBottom: '1rem', fontSize: '1.2rem', fontWeight: '700' }}>
                Clean First
              </h3>
              <p style={{ color: '#666', lineHeight: '1.7' }}>
                No filler, no mystery ingredients, no compromise. Every component serves a purpose.
              </p>
            </div>

            <div style={{
              padding: '2rem',
              background: '#fff',
              border: '1px solid #e0e0e0',
              borderLeft: '4px solid #EF4452'
            }}>
              <h3 style={{ marginBottom: '1rem', fontSize: '1.2rem', fontWeight: '700' }}>
                Science-Backed
              </h3>
              <p style={{ color: '#666', lineHeight: '1.7' }}>
                Our formulas are built on peer-reviewed research. We don't make claims we can't back up.
              </p>
            </div>

            <div style={{
              padding: '2rem',
              background: '#fff',
              border: '1px solid #e0e0e0',
              borderLeft: '4px solid #B4E61C'
            }}>
              <h3 style={{ marginBottom: '1rem', fontSize: '1.2rem', fontWeight: '700' }}>
                Convenience Obsessed
              </h3>
              <p style={{ color: '#666', lineHeight: '1.7' }}>
                Design matters. If it's not fast and easy, people won't use it. We optimize for real life.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Team */}
      <section className="section">
        <h2 className="section-title">Our Team</h2>
        <p className="section-subtitle">Built by people who care about results.</p>

        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))',
          gap: '2rem',
          maxWidth: '1200px',
          margin: '0 auto'
        }}>
          <div style={{ textAlign: 'center', padding: '1.5rem' }}>
            <div style={{
              width: '120px',
              height: '120px',
              borderRadius: '50%',
              background: '#f0f0f0',
              margin: '0 auto 1.5rem',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: '3rem'
            }}>
              👨‍💼
            </div>
            <h3 style={{ marginBottom: '0.5rem', fontWeight: '700' }}>Tommy Lezynski</h3>
            <p style={{ color: '#999', marginBottom: '1rem' }}>CEO & Co-Founder</p>
            <p style={{ fontSize: '0.9rem', color: '#666', lineHeight: '1.6' }}>
              Athlete and operator. Obsessed with clean products and performance optimization.
            </p>
          </div>

          <div style={{ textAlign: 'center', padding: '1.5rem' }}>
            <div style={{
              width: '120px',
              height: '120px',
              borderRadius: '50%',
              background: '#f0f0f0',
              margin: '0 auto 1.5rem',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: '3rem'
            }}>
              📊
            </div>
            <h3 style={{ marginBottom: '0.5rem', fontWeight: '700' }}>Niko Peixoto</h3>
            <p style={{ color: '#999', marginBottom: '1rem' }}>CFO & Co-Founder</p>
            <p style={{ fontSize: '0.9rem', color: '#666', lineHeight: '1.6' }}>
              Economics-driven founder. Focused on unit economics, scalability, and long-term growth.
            </p>
          </div>

          <div style={{ textAlign: 'center', padding: '1.5rem' }}>
            <div style={{
              width: '120px',
              height: '120px',
              borderRadius: '50%',
              background: '#f0f0f0',
              margin: '0 auto 1.5rem',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              fontSize: '3rem'
            }}>
              🎯
            </div>
            <h3 style={{ marginBottom: '0.5rem', fontWeight: '700' }}>Bobby Campagna</h3>
            <p style={{ color: '#999', marginBottom: '1rem' }}>CMO & Co-Founder</p>
            <p style={{ fontSize: '0.9rem', color: '#666', lineHeight: '1.6' }}>
              Brand visionary. Brings the voice and story that connects KATHA to the world.
            </p>
          </div>
        </div>
      </section>
    </main>
  )
}
