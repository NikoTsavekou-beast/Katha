'use client'

import { useState } from 'react'

export default function FAQ() {
  const [expandedItems, setExpandedItems] = useState({})

  const toggleItem = (id) => {
    setExpandedItems(prev => ({
      ...prev,
      [id]: !prev[id]
    }))
  }

  const faqs = [
    {
      category: 'Product',
      items: [
        {
          id: 'p1',
          q: 'What exactly is in KATHA?',
          a: 'Each stick pack contains: 3g creatine monohydrate, 1.1g electrolyte blend (potassium, magnesium, calcium), natural flavor, citric acid, and monk fruit sweetener. That\'s it. 9.8g per stick. Nothing else.'
        },
        {
          id: 'p2',
          q: 'Is creatine safe?',
          a: 'Absolutely. Creatine monohydrate is one of the most researched supplements ever. Thousands of studies confirm it\'s safe for healthy adults. It increases muscle strength and performance. No water retention, no crashes, no side effects when used as directed.'
        },
        {
          id: 'p3',
          q: 'Why monk fruit over other sweeteners?',
          a: 'Monk fruit is zero-calorie, zero-glycemic, and naturally derived. No artificial aftertaste. It\'s clean, which is the whole KATHA ethos.'
        },
        {
          id: 'p4',
          q: 'What about the electrolytes? Why those specific ones?',
          a: 'Potassium, magnesium, and calcium work together to support hydration, muscle function, and creatine absorption. The 1.1g blend is specifically dosed to complement the creatine and support peak performance without excess sodium.'
        },
        {
          id: 'p5',
          q: 'Can I mix flavors?',
          a: 'Yes. The formula is identical across all three flavors (Watermelon, Lemon Lime, Peach Mango). Mix and match. Stack them. Do whatever works for you.'
        },
        {
          id: 'p6',
          q: 'How long does it take to feel the effects?',
          a: 'Creatine typically takes 5-7 days of consistent use to reach full saturation in your muscles. Some people notice strength gains within a week. Others take 2-3 weeks. Consistency is key.'
        },
        {
          id: 'p7',
          q: 'Is KATHA vegan?',
          a: 'Yes. All ingredients are vegan-friendly.'
        }
      ]
    },
    {
      category: 'Usage',
      items: [
        {
          id: 'u1',
          q: 'How do I use KATHA?',
          a: 'Push the stick pack open. Pour into 6-8oz of water (cold or room temp). Shake for 5 seconds. Drink. No mixing bowl, no blender, no mess.'
        },
        {
          id: 'u2',
          q: 'When should I take it?',
          a: 'Pre-workout is ideal, but timing isn\'t critical. Take it whenever works for you. Consistency matters more than timing.'
        },
        {
          id: 'u3',
          q: 'Can I take it with food?',
          a: 'Yes. Food doesn\'t interfere with creatine absorption.'
        },
        {
          id: 'u4',
          q: 'Should I cycle off creatine?',
          a: 'No. Creatine is safe for long-term use. You don\'t need to cycle off. Just keep taking it consistently.'
        },
        {
          id: 'u5',
          q: 'Will it work better if I load?',
          a: 'Loading (taking 20g per day for 5 days) speeds up the saturation process, but it\'s not necessary. Consistent use at normal doses will get you there in 1-2 weeks.'
        },
        {
          id: 'u6',
          q: 'What if I miss a day?',
          a: 'One missed dose won\'t matter. Just pick back up the next day. Creatine works best with consistent use over time, not daily perfection.'
        }
      ]
    },
    {
      category: 'Shipping & Returns',
      items: [
        {
          id: 's1',
          q: 'When will my pre-order ship?',
          a: 'All July 2026 pre-orders will ship in early July 2026. You\'ll get a shipping confirmation with tracking 48 hours before your order ships.'
        },
        {
          id: 's2',
          q: 'How much does shipping cost?',
          a: 'Flat rate $5.99 for all orders within the US. Free shipping on orders over $50.'
        },
        {
          id: 's3',
          q: 'Can you ship internationally?',
          a: 'Not yet. US only for now. We\'re working on international shipping and will announce it soon.'
        },
        {
          id: 's4',
          q: 'What\'s your return policy?',
          a: 'Love it or we\'ll refund it. 30-day money-back guarantee. No questions. Open boxes are fine. We just want you satisfied.'
        },
        {
          id: 's5',
          q: 'Can I change my order after placing it?',
          a: 'Yes. Email hello@kathacreatine.com with your order number and requested changes within 24 hours of placing your order.'
        },
        {
          id: 's6',
          q: 'Do you offer subscriptions?',
          a: 'Not yet. Coming soon. For now, pre-order what you need and we\'ll have reorder options available at launch.'
        }
      ]
    },
    {
      category: 'Contact & Support',
      items: [
        {
          id: 'c1',
          q: 'I have a question not answered here.',
          a: 'Email us: hello@kathacreatine.com. We read every email and respond within 24 hours.'
        },
        {
          id: 'c2',
          q: 'I received a damaged product. What do I do?',
          a: 'Email photos to hello@kathacreatine.com and we\'ll replace it immediately. No hassle.'
        },
        {
          id: 'c3',
          q: 'Can I work with KATHA?',
          a: 'We\'re always looking for talented people. Email careers@kathacreatine.com with your interest and background.'
        }
      ]
    }
  ]

  return (
    <main>
      <section className="section">
        <h1 className="section-title">FAQ</h1>
        <p className="section-subtitle">Questions answered. Clearly.</p>

        {faqs.map((section) => (
          <div key={section.category} style={{ marginBottom: '4rem' }}>
            <h2 style={{
              fontSize: '1.5rem',
              fontWeight: '700',
              marginBottom: '2rem',
              paddingBottom: '1rem',
              borderBottom: '2px solid #e0e0e0'
            }}>
              {section.category}
            </h2>

            <div className="faq-container">
              {section.items.map((item) => (
                <div 
                  key={item.id} 
                  className={`faq-item ${expandedItems[item.id] ? 'active' : ''}`}
                  style={{ maxWidth: '800px' }}
                >
                  <div 
                    className="faq-question"
                    onClick={() => toggleItem(item.id)}
                  >
                    <span style={{ fontSize: '1.05rem' }}>{item.q}</span>
                    <span className="faq-toggle" style={{
                      display: 'inline-flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      width: '24px',
                      height: '24px',
                      fontSize: '1.3rem',
                      flexShrink: 0
                    }}>
                      {expandedItems[item.id] ? '−' : '+'}
                    </span>
                  </div>
                  <div className="faq-answer" style={{
                    fontSize: '0.95rem',
                    color: '#666',
                    lineHeight: '1.8',
                    marginTop: '1rem'
                  }}>
                    {item.a}
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </section>

      {/* CTA */}
      <section style={{
        background: '#f9f9f9',
        padding: '4rem 2rem',
        textAlign: 'center'
      }}>
        <div className="section">
          <h2 className="section-title">Still have questions?</h2>
          <p style={{
            fontSize: '1.1rem',
            color: '#666',
            marginBottom: '2rem'
          }}>
            Reach out. We're here to help.
          </p>
          <a href="/contact" className="btn btn-accent">Contact Us</a>
        </div>
      </section>
    </main>
  )
}
