'use client'

import { useState } from 'react'

export default function Shop() {
  const [cart, setCart] = useState([])
  const [selectedProduct, setSelectedProduct] = useState(null)

  const products = [
    {
      id: 1,
      name: 'KATHA Watermelon',
      flavor: 'Watermelon',
      flavorClass: 'watermelon',
      price: 2.99,
      description: 'Fresh, crisp watermelon flavor. The original.',
      specs: {
        creatine: '3g',
        electrolytes: '1.1g',
        sugar: '0g',
        servings: '1 stick'
      },
      flavorDetails: 'Natural Watermelon Flavor (SF-69083.2 & SF-69083.3), Citric Acid',
      emoji: '🍉'
    },
    {
      id: 2,
      name: 'KATHA Lemon Lime',
      flavor: 'Lemon Lime',
      flavorClass: 'lemon-lime',
      price: 2.99,
      description: 'Citrusy punch. Bright and refreshing.',
      specs: {
        creatine: '3g',
        electrolytes: '1.1g',
        sugar: '0g',
        servings: '1 stick'
      },
      flavorDetails: 'Natural Lemon Lime Flavor, Citric Acid',
      emoji: '🍋'
    },
    {
      id: 3,
      name: 'KATHA Peach Mango',
      flavor: 'Peach Mango',
      flavorClass: 'peach-mango',
      price: 2.99,
      description: 'Tropical blend. Smooth and sweet.',
      specs: {
        creatine: '3g',
        electrolytes: '1.1g',
        sugar: '0g',
        servings: '1 stick'
      },
      flavorDetails: 'Natural Mango & Pineapple Flavor, Citric Acid',
      emoji: '🥭'
    },
    {
      id: 4,
      name: 'KATHA Variety Bundle',
      flavor: 'All Three',
      flavorClass: 'variety',
      price: 34.99,
      description: '12-count variety pouch. All three flavors.',
      specs: {
        creatine: '3g per stick',
        electrolytes: '1.1g per stick',
        sugar: '0g per stick',
        servings: '12 sticks'
      },
      flavorDetails: '4x Watermelon, 4x Lemon Lime, 4x Peach Mango',
      emoji: '📦'
    }
  ]

  const addToCart = (product) => {
    setCart([...cart, product])
  }

  return (
    <main>
      <section className="section">
        <h1 className="section-title">Shop KATHA</h1>
        <p className="section-subtitle">Pre-order now. Shipping July 2026.</p>

        <div className="product-grid">
          {products.map((product) => (
            <div key={product.id} className="product-card">
              <div className="product-image">
                <div style={{ fontSize: '3rem' }}>{product.emoji}</div>
              </div>
              {product.flavorClass !== 'variety' && (
                <div className={`product-flavor ${product.flavorClass}`}>{product.flavor}</div>
              )}
              {product.flavorClass === 'variety' && (
                <div style={{
                  display: 'flex',
                  gap: '0.5rem',
                  justifyContent: 'center',
                  marginBottom: '1rem',
                  flexWrap: 'wrap'
                }}>
                  <span className="product-flavor peach-mango">Peach Mango</span>
                  <span className="product-flavor watermelon">Watermelon</span>
                  <span className="product-flavor lemon-lime">Lemon Lime</span>
                </div>
              )}
              <div className="product-name">{product.name}</div>
              <div className="product-description">{product.description}</div>
              
              <div className="product-specs">
                <div className="spec">
                  <strong>Creatine:</strong>
                  <span>{product.specs.creatine}</span>
                </div>
                <div className="spec">
                  <strong>Electrolytes:</strong>
                  <span>{product.specs.electrolytes}</span>
                </div>
                <div className="spec">
                  <strong>Sugar:</strong>
                  <span>{product.specs.sugar}</span>
                </div>
                <div className="spec">
                  <strong>Servings:</strong>
                  <span>{product.specs.servings}</span>
                </div>
              </div>

              <div style={{
                fontSize: '0.85rem',
                color: '#888',
                marginBottom: '1.5rem',
                fontStyle: 'italic'
              }}>
                {product.flavorDetails}
              </div>

              <div style={{
                display: 'flex',
                gap: '1rem',
                marginTop: '1.5rem'
              }}>
                <div style={{ flex: 1, fontSize: '1.5rem', fontWeight: '900', display: 'flex', alignItems: 'center' }}>
                  ${product.price.toFixed(2)}
                </div>
                <button 
                  onClick={() => addToCart(product)}
                  className="btn btn-accent"
                  style={{ flex: 1 }}
                >
                  Pre-Order
                </button>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* FAQ */}
      <section style={{ background: '#f9f9f9', padding: '5rem 2rem' }}>
        <div className="section">
          <h2 className="section-title">Ordering FAQ</h2>
          <p className="section-subtitle">Questions? We've got answers.</p>
          
          <div className="faq-container">
            <div className="faq-item">
              <div className="faq-question">
                <span>When will my order ship?</span>
                <span className="faq-toggle">+</span>
              </div>
              <div className="faq-answer">
                All pre-orders will ship in July 2026. You'll receive a shipping confirmation with tracking once your order is on its way.
              </div>
            </div>

            <div className="faq-item">
              <div className="faq-question">
                <span>Can I change my flavor after ordering?</span>
                <span className="faq-toggle">+</span>
              </div>
              <div className="faq-answer">
                Yes. Contact us at hello@kathacreatine.com with your order number and requested flavor change, and we'll make it happen.
              </div>
            </div>

            <div className="faq-item">
              <div className="faq-question">
                <span>What's your return policy?</span>
                <span className="faq-toggle">+</span>
              </div>
              <div className="faq-answer">
                We stand behind KATHA 100%. If you're not satisfied within 30 days, email us and we'll make it right. No questions asked.
              </div>
            </div>

            <div className="faq-item">
              <div className="faq-question">
                <span>Do you ship internationally?</span>
                <span className="faq-toggle">+</span>
              </div>
              <div className="faq-answer">
                Currently shipping to US only. International orders coming soon. Stay tuned.
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Shopify Integration Note */}
      <section className="section" style={{ background: '#f0f0f0', padding: '2rem', textAlign: 'center', borderRadius: '8px' }}>
        <h3 style={{ marginBottom: '1rem' }}>🔗 Shopify Integration</h3>
        <p style={{ color: '#666', marginBottom: '1.5rem' }}>
          This site is ready to connect to your Shopify store. Once your Shopify setup is complete, these pre-order buttons will sync with your live inventory and payment system. No code changes needed.
        </p>
        <p style={{ fontSize: '0.9rem', color: '#999' }}>
          Contact: hello@kathacreatine.com | Admin: [Shopify Store URL]
        </p>
      </section>

      <script>{`
        document.querySelectorAll('.faq-question').forEach(question => {
          question.addEventListener('click', function() {
            this.parentElement.classList.toggle('active');
          });
        });
      `}</script>
    </main>
  )
}
