'use client'

import { useState } from 'react'

export default function Contact() {
  const [submitted, setSubmitted] = useState(false)
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  })

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData(prev => ({
      ...prev,
      [name]: value
    }))
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    // In production, this would send to your backend/email service
    console.log('Form submitted:', formData)
    setSubmitted(true)
    setTimeout(() => setSubmitted(false), 5000)
  }

  return (
    <main>
      <section className="section">
        <h1 className="section-title">Get In Touch</h1>
        <p className="section-subtitle">We read every message. Respond within 24 hours.</p>

        <div style={{
          display: 'grid',
          gridTemplateColumns: '1fr 1fr',
          gap: '4rem',
          maxWidth: '1200px',
          margin: '3rem auto 0'
        }}>
          {/* Contact Form */}
          <div>
            <h3 style={{
              fontSize: '1.3rem',
              fontWeight: '700',
              marginBottom: '2rem'
            }}>
              Send us a message
            </h3>

            {submitted && (
              <div style={{
                background: '#e8f5e9',
                border: '1px solid #4caf50',
                color: '#2e7d32',
                padding: '1rem',
                marginBottom: '2rem',
                borderRadius: '4px'
              }}>
                ✓ Message received. We'll be in touch soon.
              </div>
            )}

            <form onSubmit={handleSubmit} className="contact-form">
              <div className="form-group">
                <label htmlFor="name">Name</label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={formData.name}
                  onChange={handleChange}
                  required
                  placeholder="Your name"
                />
              </div>

              <div className="form-group">
                <label htmlFor="email">Email</label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                  placeholder="your@email.com"
                />
              </div>

              <div className="form-group">
                <label htmlFor="subject">Subject</label>
                <input
                  type="text"
                  id="subject"
                  name="subject"
                  value={formData.subject}
                  onChange={handleChange}
                  required
                  placeholder="What's this about?"
                />
              </div>

              <div className="form-group">
                <label htmlFor="message">Message</label>
                <textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  required
                  placeholder="Tell us what's on your mind..."
                />
              </div>

              <button type="submit" className="btn btn-accent" style={{ width: '100%' }}>
                Send Message
              </button>
            </form>
          </div>

          {/* Contact Info */}
          <div>
            <h3 style={{
              fontSize: '1.3rem',
              fontWeight: '700',
              marginBottom: '2rem'
            }}>
              Other ways to reach us
            </h3>

            <div style={{ marginBottom: '2.5rem' }}>
              <h4 style={{
                fontSize: '1rem',
                fontWeight: '700',
                marginBottom: '0.5rem'
              }}>
                Email
              </h4>
              <a href="mailto:hello@kathacreatine.com" style={{
                color: '#EF5A22',
                textDecoration: 'none',
                fontSize: '1rem'
              }}>
                hello@kathacreatine.com
              </a>
              <p style={{
                fontSize: '0.9rem',
                color: '#999',
                marginTop: '0.5rem'
              }}>
                We respond within 24 hours.
              </p>
            </div>

            <div style={{ marginBottom: '2.5rem' }}>
              <h4 style={{
                fontSize: '1rem',
                fontWeight: '700',
                marginBottom: '0.5rem'
              }}>
                Careers
              </h4>
              <a href="mailto:careers@kathacreatine.com" style={{
                color: '#EF5A22',
                textDecoration: 'none',
                fontSize: '1rem'
              }}>
                careers@kathacreatine.com
              </a>
              <p style={{
                fontSize: '0.9rem',
                color: '#999',
                marginTop: '0.5rem'
              }}>
                We're hiring. Send your resume.
              </p>
            </div>

            <div style={{ marginBottom: '2.5rem' }}>
              <h4 style={{
                fontSize: '1rem',
                fontWeight: '700',
                marginBottom: '0.5rem'
              }}>
                Partners & Press
              </h4>
              <a href="mailto:partnerships@kathacreatine.com" style={{
                color: '#EF5A22',
                textDecoration: 'none',
                fontSize: '1rem'
              }}>
                partnerships@kathacreatine.com
              </a>
              <p style={{
                fontSize: '0.9rem',
                color: '#999',
                marginTop: '0.5rem'
              }}>
                Collaborations, press inquiries, sponsorships.
              </p>
            </div>

            <div style={{
              background: '#f9f9f9',
              padding: '2rem',
              border: '1px solid #e0e0e0',
              marginTop: '2rem'
            }}>
              <h4 style={{
                fontSize: '1rem',
                fontWeight: '700',
                marginBottom: '1rem'
              }}>
                Follow KATHA
              </h4>
              <div style={{
                display: 'flex',
                gap: '1rem'
              }}>
                <a href="https://instagram.com" target="_blank" rel="noopener noreferrer" style={{
                  color: '#EF5A22',
                  textDecoration: 'none',
                  fontSize: '0.95rem'
                }}>
                  Instagram
                </a>
                <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" style={{
                  color: '#EF5A22',
                  textDecoration: 'none',
                  fontSize: '0.95rem'
                }}>
                  Twitter
                </a>
                <a href="https://tiktok.com" target="_blank" rel="noopener noreferrer" style={{
                  color: '#EF5A22',
                  textDecoration: 'none',
                  fontSize: '0.95rem'
                }}>
                  TikTok
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ CTA */}
      <section style={{
        background: '#f9f9f9',
        padding: '4rem 2rem',
        textAlign: 'center'
      }}>
        <div className="section">
          <h2 className="section-title">Check our FAQ first</h2>
          <p style={{
            fontSize: '1.1rem',
            color: '#666',
            marginBottom: '2rem'
          }}>
            Most questions are answered there. But if you need something specific, we're here.
          </p>
          <a href="/faq" className="btn btn-secondary">View FAQ</a>
        </div>
      </section>

      {/* Social Proof */}
      <section className="section" style={{ textAlign: 'center' }}>
        <h2 className="section-title">Need help fast?</h2>
        <p className="section-subtitle">We're responsive. We care.</p>
        
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
          gap: '2rem',
          maxWidth: '1200px',
          margin: '2rem auto'
        }}>
          <div style={{ padding: '2rem' }}>
            <div style={{
              fontSize: '2rem',
              fontWeight: '900',
              marginBottom: '0.5rem',
              color: '#EF5A22'
            }}>
              24h
            </div>
            <div style={{ fontSize: '0.95rem', color: '#555' }}>
              Response time. Always.
            </div>
          </div>
          <div style={{ padding: '2rem' }}>
            <div style={{
              fontSize: '2rem',
              fontWeight: '900',
              marginBottom: '0.5rem',
              color: '#EF5A22'
            }}>
              100%
            </div>
            <div style={{ fontSize: '0.95rem', color: '#555' }}>
              Satisfaction guarantee.
            </div>
          </div>
          <div style={{ padding: '2rem' }}>
            <div style={{
              fontSize: '2rem',
              fontWeight: '900',
              marginBottom: '0.5rem',
              color: '#EF5A22'
            }}>
              Real
            </div>
            <div style={{ fontSize: '0.95rem', color: '#555' }}>
              Humans. No bots.
            </div>
          </div>
        </div>
      </section>
    </main>
  )
}
