# KATHA Website

Clean. Convenient. Creatine.

## Project Structure

```
katha-site/
├── app/
│   ├── layout.jsx          # Root layout (nav + footer)
│   ├── page.jsx            # Home page
│   ├── globals.css         # Global styles
│   ├── shop/
│   │   └── page.jsx        # Shop page
│   ├── about/
│   │   └── page.jsx        # About page
│   ├── faq/
│   │   └── page.jsx        # FAQ page
│   └── contact/
│       └── page.jsx        # Contact page
├── package.json
├── next.config.js
└── README.md
```

## Quick Start

### 1. Install Dependencies
```bash
npm install
```

### 2. Run Development Server
```bash
npm run dev
```

Open [http://localhost:3000](http://localhost:3000) in your browser.

### 3. Build for Production
```bash
npm run build
npm run start
```

## Design System

### Colors
- **Peach Mango**: #EF5A22
- **Watermelon**: #EF4452
- **Lemon Lime**: #B4E61C
- **Black**: #000 / #1a1a1a
- **White**: #fff

### Typography
- Headings: System fonts (bold)
- Body: System fonts (regular)
- Font family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto'

## Pages

### Home (`/`)
- Hero section with main pitch
- Quick facts (3g creatine, 1.1g electrolytes, 0g sugar, 3 flavors)
- Product preview cards
- Why KATHA section
- CTA to shop

### Shop (`/shop`)
- All products: 3 individual SKUs + 12-count variety pouch
- Product specs, descriptions, pricing
- Pre-order buttons (ready for Shopify integration)
- Order FAQ section

### About (`/about`)
- Brand story (ΚΆΘΑ = pure/clean)
- Why creatine + electrolytes
- Brand highlights (Founding, Standard, Vision, Promise)
- Team bios (Tommy, Niko, Bobby)

### FAQ (`/faq`)
- 4 categories: Product, Usage, Shipping & Returns, Contact & Support
- Expandable Q&A sections
- CTA to contact page

### Contact (`/contact`)
- Contact form (name, email, subject, message)
- Contact info (email, careers, partnerships)
- Social media links
- Response time guarantee (24h)

## Customization

### Editing Copy
All page content is in the `.jsx` files. Edit text directly in the pages.

### Changing Colors
Update the CSS in `app/globals.css`:
- `.peach-mango`, `.watermelon`, `.lemon-lime` classes
- `.btn-accent` button color

### Adding Images
Replace emoji placeholders with actual product images:
1. Save images to a `public/images/` folder
2. Update the `<img src="">` paths in each page
3. Build expects images at `public/images/[filename]`

Example:
```jsx
<img src="/images/3-sticks.png" alt="KATHA stick packs" />
```

## Shopify Integration

This site is ready to connect to Shopify. Two approaches:

### Option 1: Shopify Storefront API (Recommended)
Replace the "Pre-Order" buttons with actual Shopify cart links:

```jsx
// In shop/page.jsx, replace:
<a href="/shop" className="btn btn-accent">Pre-Order</a>

// With:
<a href={`https://your-store.myshopify.com/cart/add?id=${productId}`} className="btn btn-accent">
  Pre-Order
</a>
```

**Setup:**
1. Create a Shopify store and add products
2. Get your store domain (e.g., `katha.myshopify.com`)
3. Add products with their Shopify variant IDs
4. Update product IDs in `shop/page.jsx`

### Option 2: Full Shopify Integration
Create an `.env.local` file:
```
NEXT_PUBLIC_SHOPIFY_STORE_DOMAIN=your-store.myshopify.com
NEXT_PUBLIC_SHOPIFY_STOREFRONT_TOKEN=your_token_here
```

Then use the Shopify Storefront API to fetch products dynamically. (Code available on request.)

## Deployment

### Deploy to Vercel (Recommended)
1. Push your code to GitHub
2. Go to [vercel.com](https://vercel.com)
3. Import your GitHub repo
4. Click "Deploy"
5. Add domain (e.g., `kathacreatine.com`)

### Custom Domain
In your domain registrar (GoDaddy, Namecheap, etc.):
1. Point your domain's DNS to Vercel
2. Vercel will verify and enable HTTPS automatically

## Contact Form Setup

The contact form currently logs to console. To actually send emails:

### Option 1: Use Vercel's Edge Functions + SendGrid
1. Create a `pages/api/send-email.js` handler
2. Use SendGrid API to send emails
3. Update the form `onSubmit` to call this endpoint

### Option 2: Use a Service (Easier)
- **Formspree**: Free form backend, emails sent to you
- **Basin**: Similar, includes spam protection
- **Mailgun**: More powerful, developer-friendly

Example with Formspree:
```jsx
<form action="https://formspree.io/f/YOUR_FORM_ID" method="POST">
  {/* form fields */}
</form>
```

## Analytics

Add Google Analytics:
```jsx
// In app/layout.jsx, add to <head>:
<script async src="https://www.googletagmanager.com/gtag/js?id=GA_ID"></script>
<script>{`window.dataLayer = window.dataLayer || []; function gtag(){dataLayer.push(arguments);} gtag('js', new Date()); gtag('config', 'GA_ID');`}</script>
```

## Performance

- Images are lazy-loaded by default
- CSS is minimal and inlined
- No heavy dependencies
- Builds to ~50KB gzipped

## FAQ About the Site

**Q: Can I edit this without coding?**
A: Yes. All copy is in `.jsx` files—edit text like a document. Colors are in `globals.css`. For bigger changes, ask Claude.

**Q: How do I add a blog?**
A: Create `app/blog/page.jsx` and `app/blog/[slug]/page.jsx`. Content can be markdown or in a CMS (Sanity, Contentful, etc.).

**Q: Can I add an email newsletter signup?**
A: Yes. Add a form in the home hero or footer, integrate with ConvertKit/Mailchimp via their API.

**Q: What about SEO?**
A: Add metadata to each page's `export const metadata = { title: '...', description: '...' }`. Consider adding an `og-image` for social sharing.

## Support

Questions? Email: hello@kathacreatine.com

---

**Built with Next.js + React. Designed for conversion. Ready to scale.**
